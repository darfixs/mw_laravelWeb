<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\{Http, Cache, Log};

class ResenasController extends Controller
{
    /**
     * GET /api/resenas
     *
     * Llamamos a Google Places en varios idiomas: a veces Google devuelve
     * reseñas distintas según el idioma. Las consolidamos por fingerprint.
     * Caché 12h.
     */
    public function index()
    {
        $placeId = env('GOOGLE_PLACE_ID');
        $apiKey  = env('GOOGLE_VISION_API_KEY');

        if (!$placeId || !$apiKey) {
            return response()->json([
                'ok'      => false,
                'mensaje' => 'Reseñas no configuradas',
            ], 500);
        }

        $resultado = Cache::remember('resenas_google_v3', 60 * 60 * 12, function () use ($placeId, $apiKey) {

            $idiomas = ['es', 'en', 'fr', 'it', 'de'];
            $rating  = null;
            $total   = 0;
            $url     = null;
            $nombre  = 'Miss Whitney';
            $resenas = [];   // indexado por fingerprint

            foreach ($idiomas as $lang) {
                try {
                    $r = Http::timeout(15)->get(
                        'https://maps.googleapis.com/maps/api/place/details/json',
                        [
                            'place_id'                => $placeId,
                            'fields'                  => 'name,rating,user_ratings_total,reviews,url',
                            'language'                => $lang,
                            'reviews_sort'            => $lang === 'es' ? 'most_relevant' : 'newest',
                            'reviews_no_translations' => 'true',
                            'key'                     => $apiKey,
                        ]
                    );

                    if (!$r->ok()) continue;
                    $data = $r->json();
                    if (($data['status'] ?? '') !== 'OK') continue;

                    $result = $data['result'] ?? [];

                    if ($rating === null) {
                        $rating = $result['rating']             ?? null;
                        $total  = $result['user_ratings_total'] ?? 0;
                        $url    = $result['url']                ?? null;
                        $nombre = $result['name']               ?? $nombre;
                    }

                    foreach ($result['reviews'] ?? [] as $rev) {
                        $texto = trim($rev['text'] ?? '');
                        if ($texto === '') continue;
                        $autor = $rev['author_name'] ?? 'Anónimo';
                        $time  = (int) ($rev['time'] ?? 0);
                        $rRat  = (int) ($rev['rating'] ?? 5);
                        if ($rRat < 4) continue;   // solo 4 y 5 estrellas

                        // fingerprint por autor+timestamp (mismo autor en otro idioma → mismo fp)
                        $fp = hash('sha256', $autor . '|' . $time);

                        // si ya está y el nuevo texto es más largo, lo reemplazo (mejor versión)
                        if (isset($resenas[$fp]) && mb_strlen($texto) <= mb_strlen($resenas[$fp]['texto'])) {
                            continue;
                        }

                        $resenas[$fp] = [
                            'autor'           => $autor,
                            'autor_foto'      => $rev['profile_photo_url'] ?? null,
                            'rating'          => $rRat,
                            'texto'           => $texto,
                            'tiempo_relativo' => $rev['relative_time_description'] ?? null,
                            'timestamp'       => $time,
                        ];
                    }
                } catch (\Throwable $e) {
                    Log::debug("Reseñas {$lang}: " . $e->getMessage());
                    continue;
                }
            }

            // url directa de "escribir reseña" (la que pidió el cliente)
            $urlEscribir = 'https://www.google.com/maps/place/Nuevo+Restaurante+Bar+Whitney/@37.2538009,-6.9445445,17z/data=!4m8!3m7!1s0xd11d03d2c971959:0xc7a2d59e76abffa!8m2!3d37.2538009!4d-6.9445445!9m1!1b1!16s%2Fg%2F11btmcb_25';

            return [
                'ok'             => true,
                'rating_global'  => $rating,
                'total_resenas'  => $total,
                'url_google'     => $url,
                'url_escribir'   => $urlEscribir,
                'resenas'        => array_values($resenas),
                'actualizado'    => now()->toIso8601String(),
            ];
        });

        return response()->json($resultado);
    }
}
