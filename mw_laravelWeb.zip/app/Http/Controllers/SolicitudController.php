<?php
namespace App\Http\Controllers;

use App\Models\{Factura, SolicitudFactura};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{DB, Storage, Log};

class SolicitudController extends Controller
{
    public function index()
    {
        return view('cliente.solicitar-factura');
    }

    public function store(Request $request)
    {
        try {
            $data = $request->validate([
                'tipo_receptor'  => 'required|in:particular,empresa',
                'nombre_cliente' => 'required|string|max:150',
                'nombre_empresa' => 'nullable|string|max:150',
                'nif_cif'        => 'required|string|max:15',
                'email'          => 'required|email|max:200',
                'direccion'      => 'required|string|max:255',
                'codigo_postal'  => 'required|string|max:10',
                'ciudad'         => 'required|string|max:100',
                'fecha_consumo'  => 'required|date',
                'importe_ticket' => 'required|numeric|min:0.01',
                'observaciones'  => 'nullable|string|max:500',
                'atendido_por'   => 'nullable|string|max:80',
                'lineas_ticket'  => 'nullable|string',
                'acepta_lopd'    => 'required|accepted',
                'ticket'         => 'required|file|mimes:jpg,jpeg,png,webp|max:10240',
            ]);

            // Ticket adjunto (opcional)
            $ticketFilename = $ticketPath = $ticketMime = null;
            if ($request->hasFile('ticket') && $request->file('ticket')->isValid()) {
                $file = $request->file('ticket');
                $ticketFilename = uniqid('ticket_', true) . '.' . $file->getClientOriginalExtension();
                $ticketPath     = $file->storeAs('tickets', $ticketFilename, 'public');
                $ticketMime     = $file->getMimeType();
            }

            $total = (float)$data['importe_ticket'];
            $pct   = 10.0;
            $base  = round($total / (1 + $pct / 100), 2);
            $civa  = round($total - $base, 2);

            DB::beginTransaction();

            $serie      = 'MW-' . date('Y');
            $referencia = $this->generarReferencia($serie);

            $solicitud = SolicitudFactura::create([
                'referencia'     => $referencia,
                'tipo_receptor'  => $data['tipo_receptor'],
                'nombre_cliente' => $data['nombre_cliente'],
                'nombre_empresa' => $data['nombre_empresa'] ?? null,
                'nif_cif'        => strtoupper($data['nif_cif']),
                'email'          => strtolower($data['email']),
                'direccion'      => $data['direccion'],
                'codigo_postal'  => $data['codigo_postal'],
                'ciudad'         => $data['ciudad'],
                'fecha_consumo'  => $data['fecha_consumo'],
                'importe_ticket' => $total,
                'ticket_filename'=> $ticketFilename,
                'ticket_path'    => $ticketPath,
                'ticket_mime'    => $ticketMime,
                'observaciones'  => $data['observaciones'] ?? null,
                'atendido_por'   => $data['atendido_por']  ?? null,
                'acepta_lopd'    => true,
                'ip_solicitante' => $request->ip(),
                'user_agent'     => substr($request->userAgent() ?? '', 0, 500),
            ]);

            $factura = Factura::create([
                'id_solicitud'       => $solicitud->id,
                'numero_factura'     => $referencia,
                'receptor_nombre'    => $data['nombre_cliente'],
                'receptor_empresa'   => $data['nombre_empresa'] ?? null,
                'receptor_nif'       => strtoupper($data['nif_cif']),
                'receptor_email'     => strtolower($data['email']),
                'receptor_direccion' => $data['direccion'],
                'receptor_cp'        => $data['codigo_postal'],
                'receptor_ciudad'    => $data['ciudad'],
                'base_imponible'     => $base,
                'porcentaje_iva'     => $pct,
                'cuota_iva'          => $civa,
                'total_factura'      => $total,
                'concepto'           => 'Consumicion en Miss Whitney',
                'lineas_ticket'      => !empty($data['lineas_ticket']) ? json_decode($data['lineas_ticket'], true) : null,
                'fecha_consumo'      => $data['fecha_consumo'],
                'estado'             => 'pendiente',
            ]);

            DB::commit();

        } catch (\Illuminate\Validation\ValidationException $e) {
            DB::rollBack();
            $msgs = array_merge(...array_values($e->errors()));
            return response()->json(['ok' => false, 'mensaje' => implode(', ', $msgs)], 422);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('MW solicitud store: ' . $e->getMessage());
            return response()->json(['ok' => false, 'mensaje' => 'Error al guardar: ' . $e->getMessage()], 500);
        }

        // Generar PDF (no bloquea si falla)
        $pdfUrl = null;
        try {
            $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('pdf.factura', [
                'numero_factura'     => $referencia,
                'receptor_nombre'    => $data['nombre_cliente'],
                'receptor_empresa'   => $data['nombre_empresa'] ?? null,
                'receptor_nif'       => strtoupper($data['nif_cif']),
                'receptor_email'     => strtolower($data['email']),
                'receptor_direccion' => $data['direccion'],
                'receptor_cp'        => $data['codigo_postal'],
                'receptor_ciudad'    => $data['ciudad'],
                'base'               => $base,
                'civa'               => $civa,
                'total'              => $total,
                'pct_iva'            => $pct,
                'concepto'           => 'Consumicion en Miss Whitney',
                'lineas_ticket'      => !empty($data['lineas_ticket']) ? json_decode($data['lineas_ticket'], true) : null,
                'fecha_consumo'      => $data['fecha_consumo'],
                'fecha_emision'      => now(),
                'fecha_solicitud'    => now(),
                'obs_cliente'        => $data['observaciones'] ?? null,
            ])->setPaper('a4');

            $nombre = 'Factura_' . $referencia . '.pdf';
            Storage::disk('public')->put('facturas/' . $nombre, $pdf->output());
            $factura->update(['pdf_path' => 'facturas/' . $nombre]);
            $pdfUrl = url('api/facturas/' . $factura->id . '/pdf?modo=descargar');

        } catch (\Throwable $e) {
            Log::error('MW PDF cliente: ' . $e->getMessage());
            // PDF fallo, pero la solicitud ya se guardó — respondemos OK igual
        }

        return response()->json([
            'ok'         => true,
            'referencia' => $referencia,
            'email'      => strtolower($data['email']),
            'pdf_ok'     => !is_null($pdfUrl),
            'pdf_url'    => $pdfUrl,
            'factura_id' => $factura->id,
            'mensaje'    => 'Solicitud registrada correctamente',
        ]);
    }

    public function generarReferencia(string $serie): string
    {
        DB::table('contador_referencias')
            ->insertOrIgnore(['serie' => $serie, 'ultimo_numero' => 0]);
        $n = DB::table('contador_referencias')
            ->where('serie', $serie)
            ->lockForUpdate()
            ->value('ultimo_numero') + 1;
        DB::table('contador_referencias')
            ->where('serie', $serie)
            ->update(['ultimo_numero' => $n]);
        return $serie . '-' . str_pad($n, 4, '0', STR_PAD_LEFT);
    }
}
