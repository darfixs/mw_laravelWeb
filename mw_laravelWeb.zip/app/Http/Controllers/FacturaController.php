<?php
namespace App\Http\Controllers;

use App\Models\{Factura, SolicitudFactura};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{DB, Storage, Log};

class FacturaController extends Controller
{
    // ── Helpers ──────────────────────────────────────────────────
    private function generarReferencia(string $serie): string
    {
        DB::table('contador_referencias')
            ->insertOrIgnore(['serie' => $serie, 'ultimo_numero' => 0]);
        $n = DB::table('contador_referencias')
            ->where('serie', $serie)
            ->lockForUpdate()
            ->value('ultimo_numero') + 1;
        DB::table('contador_referencias')
            ->where('serie', $serie)
            ->update(['ultimo_numero' => $n]);
        return $serie . '-' . str_pad($n, 4, '0', STR_PAD_LEFT);
    }

    private function calcularIVA(float $total, float $pct = 10.0): array
    {
        $base = round($total / (1 + $pct / 100), 2);
        $civa = round($total - $base, 2);
        return ['base' => $base, 'civa' => $civa];
    }

    // ── Admin page ────────────────────────────────────────────────
    public function index()
    {
        return view('admin.index');
    }

    // ── GET /api/facturas ─────────────────────────────────────────
    public function listar()
    {
        try {
            $rows = DB::table('solicitudes_factura as s')
                ->leftJoin('facturas as f', 'f.id_solicitud', '=', 's.id')
                ->select(
                    'f.id',
                    DB::raw('COALESCE(f.numero_factura, s.referencia) as numero_factura'),
                    's.referencia as referencia_solicitud',
                    DB::raw('COALESCE(s.created_at, f.created_at, NOW()) as fecha_solicitud'),
                    DB::raw('COALESCE(f.fecha_consumo, s.fecha_consumo) as fecha_consumo'),
                    'f.fecha_emision',
                    DB::raw('COALESCE(f.receptor_nombre,  s.nombre_cliente)  as nombre_cliente'),
                    DB::raw('COALESCE(f.receptor_empresa, s.nombre_empresa)  as empresa'),
                    DB::raw("CASE
                        WHEN COALESCE(f.receptor_empresa, s.nombre_empresa) IS NOT NULL
                          AND TRIM(COALESCE(f.receptor_empresa, s.nombre_empresa)) != ''
                        THEN COALESCE(f.receptor_empresa, s.nombre_empresa)
                        ELSE COALESCE(f.receptor_nombre, s.nombre_cliente)
                    END as nombre_display"),
                    DB::raw('COALESCE(f.receptor_nif,   s.nif_cif)         as nif_cif'),
                    DB::raw('COALESCE(f.receptor_email, s.email)           as email'),
                    DB::raw('COALESCE(f.total_factura,  s.importe_ticket)  as importe'),
                    DB::raw("COALESCE(f.estado, 'pendiente')               as estado"),
                    's.observaciones as obs_cliente',
                    's.atendido_por',
                    's.ticket_filename',
                    'f.pdf_path',
                    'f.lineas_ticket'
                )
                ->orderByRaw('COALESCE(s.created_at, f.created_at) DESC')
                ->get()
                ->map(function ($row) {
                    $row->importe = (float)($row->importe ?? 0);
                    $row->lineas_ticket = $row->lineas_ticket ? json_decode($row->lineas_ticket, true) : null;
                    return $row;
                });

            return response()->json($rows);

        } catch (\Exception $e) {
            Log::error('MW listar facturas: ' . $e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    // ── POST /api/facturas ────────────────────────────────────────
    public function crear(Request $request)
    {
        try {
            $data = $request->validate([
                'nombre_cliente'       => 'required|string|max:150',
                'empresa'              => 'nullable|string|max:150',
                'nif_cif'              => 'required|string|max:15',
                'email'                => 'required|email|max:200',
                'fecha_consumo'        => 'required|date',
                'importe'              => 'required|numeric|min:0.01',
                'estado'               => 'required|in:pendiente,procesando,emitida,cancelada',
                'obs_cliente'          => 'nullable|string|max:500',
                'referencia_solicitud' => 'nullable|string',
                'lineas_ticket'        => 'nullable|array',
                'lineas_ticket.*.cantidad' => 'nullable|integer|min:1',
                'lineas_ticket.*.concepto' => 'nullable|string|max:200',
                'lineas_ticket.*.importe'  => 'nullable|numeric|min:0',
            ]);

            $total = (float)$data['importe'];
            $iva   = $this->calcularIVA($total);
            $serie = 'MW-' . date('Y');

            $idSolicitud = null;
            $referencia  = '';

            if (!empty($data['referencia_solicitud'])) {
                $sol = SolicitudFactura::where('referencia', $data['referencia_solicitud'])->first();
                if ($sol) {
                    $idSolicitud = $sol->id;
                    $referencia  = $sol->referencia;
                }
            }

            if (!$idSolicitud) {
                DB::beginTransaction();
                $referencia  = $this->generarReferencia($serie);
                $sol = SolicitudFactura::create([
                    'referencia'     => $referencia,
                    'tipo_receptor'  => 'particular',
                    'nombre_cliente' => $data['nombre_cliente'],
                    'nombre_empresa' => $data['empresa'] ?? null,
                    'nif_cif'        => strtoupper($data['nif_cif']),
                    'email'          => strtolower($data['email']),
                    'direccion'      => 'Alta manual admin',
                    'codigo_postal'  => '00000',
                    'ciudad'         => 'N/A',
                    'fecha_consumo'  => $data['fecha_consumo'],
                    'importe_ticket' => $total,
                    'acepta_lopd'    => true,
                    'ip_solicitante' => '127.0.0.1',
                ]);
                $idSolicitud = $sol->id;
                DB::commit();
            }

            $f = Factura::create([
                'id_solicitud'       => $idSolicitud,
                'numero_factura'     => $referencia,
                'receptor_nombre'    => $data['nombre_cliente'],
                'receptor_empresa'   => $data['empresa'] ?? null,
                'receptor_nif'       => strtoupper($data['nif_cif']),
                'receptor_email'     => strtolower($data['email']),
                'receptor_direccion' => 'Alta manual admin',
                'receptor_cp'        => '00000',
                'receptor_ciudad'    => 'N/A',
                'base_imponible'     => $iva['base'],
                'porcentaje_iva'     => 10,
                'cuota_iva'          => $iva['civa'],
                'total_factura'      => $total,
                'concepto'           => 'Consumicion en Miss Whitney',
                'lineas_ticket'      => $data['lineas_ticket'] ?? null,
                'fecha_consumo'      => $data['fecha_consumo'],
                'estado'             => $data['estado'],
                'fecha_emision'      => $data['estado'] === 'emitida' ? now() : null,
                'admin_usuario'      => 'admin',
            ]);

            return response()->json([
                'id'                   => $f->id,
                'numero_factura'       => $f->numero_factura,
                'referencia_solicitud' => $referencia,
                'fecha_solicitud'      => $f->created_at,
                'fecha_consumo'        => $f->fecha_consumo,
                'nombre_cliente'       => $f->receptor_nombre,
                'empresa'              => $f->receptor_empresa,
                'nombre_display'       => $f->receptor_empresa ?: $f->receptor_nombre,
                'nif_cif'              => $f->receptor_nif,
                'email'                => $f->receptor_email,
                'importe'              => $f->total_factura,
                'estado'               => $f->estado,
                'obs_cliente'          => $data['obs_cliente'] ?? null,
                'lineas_ticket'        => $f->lineas_ticket,
                'pdf_path'             => null,
            ]);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json(['ok' => false, 'mensaje' => implode(', ', array_merge(...array_values($e->errors())))], 422);
        } catch (\Exception $e) {
            Log::error('MW crear factura admin: ' . $e->getMessage());
            return response()->json(['ok' => false, 'mensaje' => $e->getMessage()], 500);
        }
    }

    // ── POST /api/facturas/{id} ───────────────────────────────────
    public function actualizar(Request $request, int $id)
    {
        try {
            $f = Factura::findOrFail($id);

            $data = $request->validate([
                'nombre_cliente' => 'required|string|max:150',
                'empresa'        => 'nullable|string|max:150',
                'nif_cif'        => 'required|string|max:15',
                'email'          => 'required|email|max:200',
                'fecha_consumo'  => 'required|date',
                'importe'        => 'required|numeric|min:0.01',
                'estado'         => 'required|in:pendiente,procesando,emitida,cancelada',
                'obs_cliente'    => 'nullable|string|max:500',
                'lineas_ticket'              => 'nullable|array',
                'lineas_ticket.*.cantidad'   => 'nullable|integer|min:1',
                'lineas_ticket.*.concepto'   => 'nullable|string|max:200',
                'lineas_ticket.*.importe'    => 'nullable|numeric|min:0',
            ]);

            $total = (float)$data['importe'];
            $iva   = $this->calcularIVA($total);

            $f->update([
                'receptor_nombre'  => $data['nombre_cliente'],
                'receptor_empresa' => $data['empresa'] ?? null,
                'receptor_nif'     => strtoupper($data['nif_cif']),
                'receptor_email'   => strtolower($data['email']),
                'fecha_consumo'    => $data['fecha_consumo'],
                'base_imponible'   => $iva['base'],
                'cuota_iva'        => $iva['civa'],
                'total_factura'    => $total,
                'lineas_ticket'    => $data['lineas_ticket'] ?? null,
                'estado'           => $data['estado'],
                'fecha_emision'    => $data['estado'] === 'emitida' && !$f->fecha_emision ? now() : $f->fecha_emision,
                'admin_usuario'    => 'admin',
            ]);

            return response()->json([
                'id'             => $f->id,
                'numero_factura' => $f->numero_factura,
                'nombre_cliente' => $f->receptor_nombre,
                'empresa'        => $f->receptor_empresa,
                'nombre_display' => $f->receptor_empresa ?: $f->receptor_nombre,
                'nif_cif'        => $f->receptor_nif,
                'email'          => $f->receptor_email,
                'importe'        => $f->total_factura,
                'estado'         => $f->estado,
                'fecha_consumo'  => $f->fecha_consumo,
                'obs_cliente'    => $data['obs_cliente'] ?? null,
                'lineas_ticket'  => $f->lineas_ticket,
            ]);

        } catch (\Exception $e) {
            Log::error('MW actualizar factura: ' . $e->getMessage());
            return response()->json(['ok' => false, 'mensaje' => $e->getMessage()], 500);
        }
    }

    // ── POST /api/facturas/{id}/estado ────────────────────────────
    public function cambiarEstado(Request $request, int $id)
    {
        try {
            $f      = Factura::findOrFail($id);
            $estado = $request->validate([
                'estado' => 'required|in:pendiente,procesando,emitida,cancelada',
            ])['estado'];

            $f->update([
                'estado'        => $estado,
                'fecha_emision' => $estado === 'emitida' && !$f->fecha_emision ? now() : $f->fecha_emision,
            ]);

            return response()->json(['ok' => true, 'id' => $id, 'estado' => $estado]);

        } catch (\Exception $e) {
            Log::error('MW cambiar estado: ' . $e->getMessage());
            return response()->json(['ok' => false, 'mensaje' => $e->getMessage()], 500);
        }
    }

    // ── POST /api/facturas/{id}/delete  +  DELETE /api/facturas/{id} ──
    public function eliminar(int $id)
    {
        try {
            $f = Factura::findOrFail($id);

            if ($f->pdf_path && Storage::disk('public')->exists($f->pdf_path)) {
                Storage::disk('public')->delete($f->pdf_path);
            }

            $ref = $f->numero_factura;
            $f->delete();

            return response()->json(['ok' => true, 'id' => $id, 'numero_factura' => $ref]);

        } catch (\Exception $e) {
            Log::error('MW eliminar factura: ' . $e->getMessage());
            return response()->json(['ok' => false, 'mensaje' => $e->getMessage()], 500);
        }
    }

    // ── GET /api/facturas/{id}/pdf ────────────────────────────────
    public function descargarPdf(int $id, Request $request)
    {
        try {
            $f    = Factura::with('solicitud')->findOrFail($id);
            $modo = $request->get('modo', 'ver');

            if ($f->pdf_path && Storage::disk('public')->exists($f->pdf_path)) {
                $nombre = 'Factura_' . $f->numero_factura . '.pdf';
                return $modo === 'descargar'
                    ? Storage::disk('public')->download($f->pdf_path, $nombre)
                    : response(Storage::disk('public')->get($f->pdf_path), 200, ['Content-Type' => 'application/pdf']);
            }

            $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('pdf.factura', [
                'numero_factura'     => $f->numero_factura,
                'receptor_nombre'    => $f->receptor_nombre,
                'receptor_empresa'   => $f->receptor_empresa,
                'receptor_nif'       => $f->receptor_nif,
                'receptor_email'     => $f->receptor_email,
                'receptor_direccion' => $f->receptor_direccion,
                'receptor_cp'        => $f->receptor_cp,
                'receptor_ciudad'    => $f->receptor_ciudad,
                'base'               => $f->base_imponible,
                'civa'               => $f->cuota_iva,
                'total'              => $f->total_factura,
                'pct_iva'            => $f->porcentaje_iva,
                'concepto'           => $f->concepto,
                'lineas_ticket'      => $f->lineas_ticket,
                'fecha_consumo'      => $f->fecha_consumo,
                'fecha_emision'      => $f->fecha_emision,
                'fecha_solicitud'    => $f->created_at,
                'obs_cliente'        => $f->solicitud->observaciones ?? null,
            ])->setPaper('a4');

            $nombre = 'Factura_' . $f->numero_factura . '.pdf';
            Storage::disk('public')->put('facturas/' . $nombre, $pdf->output());
            $f->update(['pdf_path' => 'facturas/' . $nombre]);

            return $modo === 'descargar' ? $pdf->download($nombre) : $pdf->stream($nombre);

        } catch (\Exception $e) {
            Log::error('MW PDF: ' . $e->getMessage());
            return response()->json(['ok' => false, 'mensaje' => $e->getMessage()], 500);
        }
    }
    // ── POST /api/facturas/{id}/email ─────────────────────────────
    //  Envía el PDF de la factura al email indicado (o al del receptor)
    public function enviarPorEmail(int $id, Request $request)
    {
        try {
            $data = $request->validate([
                'email' => 'nullable|email|max:200',
            ]);

            $f = Factura::with('solicitud')->findOrFail($id);
            $destino = !empty($data['email']) ? $data['email'] : $f->receptor_email;

            if (!$destino) {
                return response()->json(['ok' => false, 'mensaje' => 'No hay email destino'], 422);
            }

            // 1. Asegurar que el PDF existe en disco; si no, regenerarlo
            $pdfPath = $f->pdf_path;
            if (!$pdfPath || !Storage::disk('public')->exists($pdfPath)) {
                $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('pdf.factura', [
                    'numero_factura'     => $f->numero_factura,
                    'receptor_nombre'    => $f->receptor_nombre,
                    'receptor_empresa'   => $f->receptor_empresa,
                    'receptor_nif'       => $f->receptor_nif,
                    'receptor_email'     => $f->receptor_email,
                    'receptor_direccion' => $f->receptor_direccion,
                    'receptor_cp'        => $f->receptor_cp,
                    'receptor_ciudad'    => $f->receptor_ciudad,
                    'base'               => $f->base_imponible,
                    'civa'               => $f->cuota_iva,
                    'total'              => $f->total_factura,
                    'pct_iva'            => $f->porcentaje_iva,
                    'concepto'           => $f->concepto,
                'lineas_ticket'      => $f->lineas_ticket,
                    'fecha_consumo'      => $f->fecha_consumo,
                    'fecha_emision'      => $f->fecha_emision,
                    'fecha_solicitud'    => $f->created_at,
                    'obs_cliente'        => $f->solicitud->observaciones ?? null,
                ])->setPaper('a4');

                $nombre  = 'Factura_' . $f->numero_factura . '.pdf';
                $pdfPath = 'facturas/' . $nombre;
                Storage::disk('public')->put($pdfPath, $pdf->output());
                $f->update(['pdf_path' => $pdfPath]);
            }

            $absPath  = Storage::disk('public')->path($pdfPath);
            $pdfNombre = 'Factura_' . $f->numero_factura . '.pdf';
            $nombreReceptor = !empty($f->receptor_empresa) ? $f->receptor_empresa : $f->receptor_nombre;

            // 2. Enviar
            \Mail::to($destino)->send(new \App\Mail\FacturaMail(
                $f->numero_factura,
                $nombreReceptor,
                $absPath,
                $pdfNombre
            ));

            return response()->json([
                'ok'      => true,
                'mensaje' => 'Factura enviada a ' . $destino,
                'email'   => $destino,
            ]);

        } catch (\Exception $e) {
            Log::error('MW enviar email factura: ' . $e->getMessage());
            return response()->json(['ok' => false, 'mensaje' => $e->getMessage()], 500);
        }
    }

}
