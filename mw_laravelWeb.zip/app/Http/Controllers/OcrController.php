<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\{Http, Log};

class OcrController extends Controller
{
    /**
     * POST /api/ocr/ticket
     *
     * Extrae del ticket: fecha, total, líneas (concepto+importe), atendido_por.
     * La base imponible y el IVA NO se extraen — se calculan en backend desde el total.
     */
    public function procesarTicket(Request $request)
    {
        $request->validate([
            'ticket' => 'required|file|mimes:jpg,jpeg,png,webp|max:10240',
        ]);

        try {
            $apiKey = env('GOOGLE_VISION_API_KEY');
            if (!$apiKey) {
                return response()->json(['ok' => false, 'mensaje' => 'OCR no configurado'], 500);
            }

            $imageBase64 = base64_encode(file_get_contents($request->file('ticket')->getRealPath()));

            $response = Http::timeout(30)->post(
                'https://vision.googleapis.com/v1/images:annotate?key=' . $apiKey,
                [
                    'requests' => [[
                        'image'    => ['content' => $imageBase64],
                        'features' => [['type' => 'DOCUMENT_TEXT_DETECTION', 'maxResults' => 1]],
                        'imageContext' => ['languageHints' => ['es']],
                    ]],
                ]
            );

            if (!$response->ok()) {
                Log::error('OCR Vision: ' . $response->body());
                return response()->json(['ok' => false, 'mensaje' => 'Vision API error'], 500);
            }

            $texto = $response->json()['responses'][0]['fullTextAnnotation']['text'] ?? '';
            if (!$texto) {
                return response()->json(['ok' => false, 'mensaje' => 'No se detectó texto'], 422);
            }

            $extracted = $this->parsearTicket($texto);
            $extracted['ok']        = true;
            $extracted['texto_raw'] = mb_convert_encoding($texto, 'UTF-8', 'UTF-8');

            // Forzar UTF-8 válido en cualquier string del array (Vision a veces devuelve bytes raros)
            array_walk_recursive($extracted, function (&$v) {
                if (is_string($v)) {
                    $v = mb_convert_encoding($v, 'UTF-8', 'UTF-8');
                }
            });

            return response()->json($extracted);

        } catch (\Exception $e) {
            Log::error('OCR ticket: ' . $e->getMessage());
            return response()->json(['ok' => false, 'mensaje' => $e->getMessage()], 500);
        }
    }

    private function parsearTicket(string $texto): array
    {
        $resultado = [
            'fecha'         => null,
            'hora'          => null,
            'lineas'        => [],
            'total'         => null,
            'atendido_por'  => null,
        ];

        $lineas = array_values(array_filter(
            array_map('trim', preg_split("/\r\n|\n|\r/", $texto)),
            fn($l) => $l !== ''
        ));

        $count = count($lineas);
        for ($idx = 0; $idx < $count; $idx++) {
            $linea = $lineas[$idx];

            // Fecha + hora
            if (preg_match('/(\d{2}\/\d{2}\/\d{4})\s+(\d{1,2}:\d{2})/', $linea, $m)) {
                $resultado['fecha'] = $this->normalizarFecha($m[1]);
                $resultado['hora']  = $m[2];
            } elseif (!$resultado['fecha'] && preg_match('/(\d{2}\/\d{2}\/\d{4})/', $linea, $m)) {
                $resultado['fecha'] = $this->normalizarFecha($m[1]);
            }

            // Atendido
            if (preg_match('/le\s+atendi[óo]\s*:?\s*(.+)/i', $linea, $m)) {
                $resultado['atendido_por'] = trim($m[1]);
            }

            // Total: "Total: 2,50 €"
            if (preg_match('/^total\s*:?\s*([\d.,]+)\s*€?/i', $linea, $m)) {
                $valor = $this->parseNumero($m[1]);
                if ($valor !== null && $valor > 0) {
                    $resultado['total'] = $valor;
                }
            }

            // ─── DETECCIÓN DE LÍNEAS DE PRODUCTOS ─────────────
            // Google Vision devuelve cada celda en línea separada, ej:
            //   linea[i]   = "1 CAFE CON LECHE"   (cantidad + concepto)
            //   linea[i+1] = "1,40 €"             (precio unitario)
            //   linea[i+2] = "1,40 €"             (importe total)

            // Detectamos línea que empieza con "<número> <texto>" sin €
            if (preg_match('/^(\d{1,3})\s+([A-ZÁÉÍÓÚÑa-záéíóúñ\/\.\-\s]{2,}?)$/u', $linea, $m)
                && !preg_match('/€|total|base|iva|imponible|factura|concepto/i', $linea)) {

                $cantidad = (int)$m[1];
                $concepto = trim(preg_replace('/\s+/', ' ', $m[2]));

                // Buscar las próximas 1-2 líneas que parezcan precios
                $precio  = null;
                $importe = null;
                if (isset($lineas[$idx + 1])
                    && preg_match('/^([\d.,]+)\s*€?\s*$/', $lineas[$idx + 1], $p1)) {
                    $precio = $this->parseNumero($p1[1]);
                }
                if (isset($lineas[$idx + 2])
                    && preg_match('/^([\d.,]+)\s*€?\s*$/', $lineas[$idx + 2], $p2)) {
                    $importe = $this->parseNumero($p2[1]);
                }

                // Filtros
                if ($cantidad > 0 && $cantidad < 100
                    && strlen($concepto) >= 2
                    && $importe !== null && $importe > 0
                    && !preg_match('/total|base|iva|i\.v\.a|imponible/i', $concepto)) {
                    $resultado['lineas'][] = [
                        'cantidad' => $cantidad,
                        'concepto' => strtoupper($concepto),
                        'importe'  => $importe,
                    ];
                    // Saltar las dos líneas de precios ya consumidas
                    $idx += 2;
                }
            }
        }

        return $resultado;
    }

    private function normalizarFecha(string $fecha): string
    {
        $partes = explode('/', $fecha);
        if (count($partes) === 3) {
            return sprintf('%04d-%02d-%02d', $partes[2], $partes[1], $partes[0]);
        }
        return $fecha;
    }

    private function parseNumero(string $valor): ?float
    {
        $limpio = str_replace(['€', ' '], '', $valor);
        if (substr_count($limpio, ',') === 1 && substr_count($limpio, '.') === 0) {
            $limpio = str_replace(',', '.', $limpio);
        } elseif (substr_count($limpio, ',') === 1 && substr_count($limpio, '.') >= 1) {
            $limpio = str_replace('.', '', $limpio);
            $limpio = str_replace(',', '.', $limpio);
        }
        return is_numeric($limpio) ? (float)$limpio : null;
    }
}
