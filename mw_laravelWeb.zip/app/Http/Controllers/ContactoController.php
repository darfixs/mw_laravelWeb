<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\{Mail, Log};

class ContactoController extends Controller
{
    public function enviar(Request $request)
    {
        try {
            $data = $request->validate([
                'nombre'  => 'required|string|max:120',
                'email'   => 'required|email|max:200',
                'asunto'  => 'nullable|string|max:120',
                'mensaje' => 'required|string|max:2000',
            ]);

            $asunto  = $data['asunto'] ?? 'Consulta general';
            $destino = env('MAIL_FROM_ADDRESS', 'misswhitneyfacturas@gmail.com');

            Mail::send([], [], function ($m) use ($data, $asunto, $destino) {
                $m->to($destino)
                  ->replyTo($data['email'], $data['nombre'])
                  ->subject('[Web MW] ' . $asunto . ' · ' . $data['nombre'])
                  ->html(
                      '<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto">'
                    . '<div style="background:#7b1c2b;padding:18px 24px">'
                    . '<h2 style="margin:0;color:#fff;font-style:italic">Miss Whitney</h2>'
                    . '</div>'
                    . '<div style="padding:24px;background:#fff;border:1px solid #f0e7d8">'
                    . '<p style="margin:0 0 6px"><strong>Nombre:</strong> ' . htmlspecialchars($data['nombre']) . '</p>'
                    . '<p style="margin:0 0 6px"><strong>Email:</strong> ' . htmlspecialchars($data['email']) . '</p>'
                    . '<p style="margin:0 0 6px"><strong>Asunto:</strong> ' . htmlspecialchars($asunto) . '</p>'
                    . '<hr style="border:none;border-top:1px solid #f0e7d8;margin:14px 0">'
                    . '<p style="white-space:pre-wrap;margin:0;color:#333">' . htmlspecialchars($data['mensaje']) . '</p>'
                    . '</div>'
                    . '<p style="font-size:11px;color:#999;text-align:center;margin-top:8px">'
                    . 'Mensaje enviado desde el formulario de contacto de misswhitney.es</p>'
                    . '</div>'
                  );
            });

            return response()->json(['ok' => true, 'mensaje' => 'Mensaje enviado correctamente']);

        } catch (\Illuminate\Validation\ValidationException $e) {
            $msgs = array_merge(...array_values($e->errors()));
            return response()->json(['ok' => false, 'mensaje' => implode(', ', $msgs)], 422);
        } catch (\Exception $e) {
            Log::error('MW contacto: ' . $e->getMessage());
            return response()->json(['ok' => false, 'mensaje' => 'Error al enviar el mensaje. Inténtalo de nuevo.'], 500);
        }
    }
}
