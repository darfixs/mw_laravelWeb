<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\{Mail, Log};

class ReservaController extends Controller
{
    public function enviar(Request $request)
    {
        try {
            $data = $request->validate([
                'nombre'   => 'required|string|max:120',
                'telefono' => 'required|string|max:20',
                'email'    => 'nullable|email|max:200',
                'fecha'    => 'required|date',
                'hora'     => 'required|string|max:10',
                'personas' => 'required|integer|min:1|max:50',
                'notas'    => 'nullable|string|max:500',
            ]);

            $destino = env('MAIL_FROM_ADDRESS', 'misswhitneyfacturas@gmail.com');

            $fecha_fmt = \Carbon\Carbon::parse($data['fecha'])->translatedFormat('l, j \d\e F \d\e Y');

            $html =
                '<div style="font-family:Arial,sans-serif;max-width:580px;margin:0 auto">'
              . '<div style="background:#7b1c2b;padding:18px 24px;border-radius:8px 8px 0 0">'
              . '<h2 style="margin:0;color:#fff;font-style:italic;font-size:22px">Miss Whitney</h2>'
              . '<p style="margin:4px 0 0;color:rgba(255,255,255,.7);font-size:13px">Nueva solicitud de reserva</p>'
              . '</div>'
              . '<div style="padding:24px 28px;background:#fff;border:1px solid #f0e7d8;border-top:none">'
              . '<table style="width:100%;border-collapse:collapse;font-size:15px">'
              . '<tr><td style="padding:8px 0;border-bottom:1px solid #f5ede8;color:#888;width:140px">Nombre</td>'
              . '<td style="padding:8px 0;border-bottom:1px solid #f5ede8;font-weight:600;color:#1a1a1a">' . htmlspecialchars($data['nombre']) . '</td></tr>'
              . '<tr><td style="padding:8px 0;border-bottom:1px solid #f5ede8;color:#888">Teléfono</td>'
              . '<td style="padding:8px 0;border-bottom:1px solid #f5ede8;font-weight:600;color:#1a1a1a">' . htmlspecialchars($data['telefono']) . '</td></tr>'
              . '<tr><td style="padding:8px 0;border-bottom:1px solid #f5ede8;color:#888">Email</td>'
              . '<td style="padding:8px 0;border-bottom:1px solid #f5ede8;color:#1a1a1a">' . htmlspecialchars($data['email'] ?? '—') . '</td></tr>'
              . '<tr><td style="padding:8px 0;border-bottom:1px solid #f5ede8;color:#888">Fecha</td>'
              . '<td style="padding:8px 0;border-bottom:1px solid #f5ede8;font-weight:600;color:#7b1c2b">' . $fecha_fmt . '</td></tr>'
              . '<tr><td style="padding:8px 0;border-bottom:1px solid #f5ede8;color:#888">Hora</td>'
              . '<td style="padding:8px 0;border-bottom:1px solid #f5ede8;font-weight:600;color:#7b1c2b">' . htmlspecialchars($data['hora']) . '</td></tr>'
              . '<tr><td style="padding:8px 0;border-bottom:1px solid #f5ede8;color:#888">Personas</td>'
              . '<td style="padding:8px 0;border-bottom:1px solid #f5ede8;font-weight:600;color:#1a1a1a">' . $data['personas'] . '</td></tr>'
              . '</table>';

            if (!empty($data['notas'])) {
                $html .= '<div style="margin-top:16px;padding:14px;background:#fdf5f0;border-radius:8px;border-left:3px solid #7b1c2b">'
                       . '<p style="margin:0 0 4px;font-size:12px;color:#888;text-transform:uppercase;letter-spacing:.08em">Notas</p>'
                       . '<p style="margin:0;color:#333;white-space:pre-wrap">' . htmlspecialchars($data['notas']) . '</p>'
                       . '</div>';
            }

            $html .= '</div>'
                   . '<p style="font-size:11px;color:#aaa;text-align:center;padding:10px">Reserva recibida desde misswhitney.es</p>'
                   . '</div>';

            Mail::send([], [], function ($m) use ($data, $destino, $html) {
                $m->to($destino)
                  ->subject('🍽️ Nueva reserva — ' . $data['nombre'] . ' · ' . $data['fecha'] . ' ' . $data['hora'])
                  ->html($html);

                // Reply-to al email del cliente si lo ha dado
                if (!empty($data['email'])) {
                    $m->replyTo($data['email'], $data['nombre']);
                }
            });

            return response()->json(['ok' => true]);

        } catch (\Illuminate\Validation\ValidationException $e) {
            $msgs = array_merge(...array_values($e->errors()));
            return response()->json(['ok' => false, 'mensaje' => implode(', ', $msgs)], 422);
        } catch (\Exception $e) {
            Log::error('MW reserva: ' . $e->getMessage());
            return response()->json(['ok' => false, 'mensaje' => 'Error al enviar. Inténtalo de nuevo.'], 500);
        }
    }
}
