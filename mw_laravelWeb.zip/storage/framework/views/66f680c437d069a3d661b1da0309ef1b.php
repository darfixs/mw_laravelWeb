<?php $__env->startSection('title','Reservar · Miss Whitney'); ?>

<?php $__env->startPush('styles'); ?>
<style>
  .res-card {
    max-width: 640px; margin: 0 auto;
    padding: 1.4rem 1.5rem 1.5rem;
    background: rgba(255,255,255,.95);
    backdrop-filter: blur(14px);
    border: 1px solid rgba(255,255,255,.9);
    box-shadow: var(--shadow-lg);
    border-radius: 24px;
  }

  /* En modo embedded el card es la ventana entera */
  body.is-embedded .res-card {
    background: #fff;
    box-shadow: 0 30px 80px rgba(0,0,0,.4);
    padding: 2.2rem 2rem 2rem;
    margin: clamp(20px, 4vw, 50px) auto;
  }
  @media (max-width: 600px) {
    body.is-embedded .res-card {
      margin: 0; border-radius: 0;
      min-height: 100vh; min-height: 100dvh;
      padding: 3.5rem 1.2rem 2rem;  /* top = espacio para el botón X fijo */
    }
  }
  .res-card__head {
    display: flex; align-items: center; justify-content: space-between;
    gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap;
  }
  .res-card__head h2 {
    font-size: 1.5rem; margin: 0;
    color: var(--burdeos-osc);
  }
  .info-btn {
    display: inline-flex; align-items: center; gap: .4rem;
    background: var(--burdeos-pale);
    color: var(--burdeos);
    border: 1px solid rgba(155,26,46,.2);
    padding: .45rem .85rem; border-radius: 999px;
    font-size: .82rem; font-weight: 600;
    cursor: pointer;
    transition: background .18s, transform .18s;
  }
  .info-btn:hover { background: #fce8ec; transform: translateY(-1px) }

  .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem }
  @media (max-width: 500px) { .form-row { grid-template-columns: 1fr } }

  .personas-grid {
    display: grid; grid-template-columns: repeat(6,1fr); gap: .4rem; margin-top: .38rem;
  }
  .pers-btn {
    aspect-ratio: 1; border-radius: 10px;
    border: 1.5px solid var(--gris-claro);
    background: rgba(255,255,255,.8);
    font-weight: 700; font-size: .9rem; cursor: pointer;
    transition: all .18s ease;
  }
  .pers-btn:hover { border-color: var(--burdeos); color: var(--burdeos) }
  .pers-btn.selected {
    background: var(--burdeos); color: #fff; border-color: var(--burdeos);
    box-shadow: 0 4px 12px rgba(155,26,46,.22);
  }

  /* Modal interno de Información útil */
  .info-overlay {
    position: fixed; inset: 0; z-index: 200;
    display: none;
    background: rgba(20,10,10,.55);
    backdrop-filter: blur(4px);
    align-items: center; justify-content: center;
    padding: 1rem;
    animation: infoFade .25s ease;
  }
  .info-overlay.is-open { display: flex }
  @keyframes infoFade { from { opacity: 0 } to { opacity: 1 } }

  .info-panel {
    background: #fff;
    border-radius: 20px;
    width: min(480px, 100%);
    max-height: 86vh; overflow-y: auto;
    padding: 1.6rem 1.8rem;
    box-shadow: 0 24px 60px rgba(0,0,0,.35);
    animation: infoSlide .35s cubic-bezier(.22,1,.36,1);
  }
  @keyframes infoSlide { from { transform: translateY(20px); opacity: 0 } to { transform: none; opacity: 1 } }

  .info-panel__head {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 1.2rem;
  }
  .info-panel__head h3 {
    margin: 0; font-size: 1.4rem;
    color: var(--burdeos-osc);
  }
  .info-panel__close {
    width: 32px; height: 32px; border-radius: 50%;
    border: none; background: var(--burdeos-pale);
    color: var(--burdeos); cursor: pointer;
    display: grid; place-items: center;
    transition: background .18s, transform .18s;
  }
  .info-panel__close:hover { background: #fce8ec; transform: rotate(90deg) }

  .info-row {
    display: flex; gap: .9rem; align-items: flex-start;
    padding: .85rem 0;
    border-bottom: 1px solid rgba(155,26,46,.08);
  }
  .info-row:last-child { border-bottom: none }
  .info-ico { font-size: 1.35rem; flex-shrink: 0 }
  .info-row strong { display: block; font-size: .9rem; color: var(--negro); margin-bottom: .15rem }
  .info-row span { font-size: .82rem; color: var(--gris); line-height: 1.55 }

  /* éxito */
  .success-msg { display: none; text-align: center; padding: 2rem 1rem }
  .success-msg .check { font-size: 3rem; margin-bottom: .8rem }
  .success-msg h3 { font-size: 1.5rem; margin-bottom: .3rem }
  .success-msg p { color: var(--gris); margin: 0 }


  /* Cuando aparece dentro del modal iframe → menos espacio */
  /* ── Modal embedded: márgenes simétricos ── */
  body.is-embedded .page-wrap {
    padding: 1rem !important;
    max-width: 100% !important;
    min-height: 0 !important;
  }
  body.is-embedded .res-card {
    max-width: 100%;        /* el card ocupa todo el ancho disponible */
    padding: 1.2rem 1.4rem 1.4rem;
    margin: 0;              /* sin auto-center, ya está centrado por el page-wrap */
  }
  body.is-embedded .res-card__head { margin-bottom: 1rem }
  body.is-embedded .field { margin-bottom: .7rem }
  body.is-embedded .field label { margin-bottom: .25rem; font-size: .82rem }
  body.is-embedded .field input,
  body.is-embedded .field select,
  body.is-embedded .field textarea { padding: .55rem .8rem }
  body.is-embedded .field textarea { min-height: 70px }
  body.is-embedded .pers-btn { font-size: .82rem }
  body.is-embedded .form-row { gap: .7rem }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<main class="page-wrap">

  <div class="res-card">
    <div class="res-card__head">
      <h2>Datos de la reserva</h2>
      <button type="button" class="info-btn" onclick="openInfo()">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>
        </svg>
        Información útil
      </button>
    </div>

    <div id="form-area">
      <div class="form-row">
        <div class="field">
          <label for="r-nombre">Nombre completo *</label>
          <input type="text" id="r-nombre" placeholder="Tu nombre" required/>
        </div>
        <div class="field">
          <label for="r-tel">Teléfono *</label>
          <input type="tel" id="r-tel" placeholder="6XX XXX XXX" required/>
        </div>
      </div>
      <div class="field">
        <label for="r-email">Email</label>
        <input type="email" id="r-email" placeholder="tu@correo.es"/>
      </div>
      <div class="form-row">
        <div class="field">
          <label for="r-fecha">Fecha *</label>
          <input type="date" id="r-fecha" required/>
        </div>
        <div class="field">
          <label for="r-hora">Hora *</label>
          <select id="r-hora">
            <option value="">Selecciona</option>
            <option>08:00</option><option>09:00</option><option>10:00</option>
            <option>11:00</option><option>12:00</option><option>13:00</option>
            <option>14:00</option><option>15:00</option><option>16:00</option>
          </select>
        </div>
      </div>
      <div class="field">
        <label>Número de personas *</label>
        <div class="personas-grid" id="pers-grid">
          <button class="pers-btn" type="button" onclick="setPers(1,this)">1</button>
          <button class="pers-btn" type="button" onclick="setPers(2,this)">2</button>
          <button class="pers-btn" type="button" onclick="setPers(3,this)">3</button>
          <button class="pers-btn" type="button" onclick="setPers(4,this)">4</button>
          <button class="pers-btn" type="button" onclick="setPers(5,this)">5</button>
          <button class="pers-btn" type="button" onclick="setPers(6,this)">6+</button>
        </div>
      </div>
      <div class="field">
        <label for="r-notas">Notas o peticiones especiales</label>
        <textarea id="r-notas" placeholder="Alergias, ocasión especial, zona preferida…"></textarea>
      </div>
      <button class="btn-primary" onclick="submitReserva()" style="width:100%">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13M22 2L15 22l-4-9-9-4 19-7z"/></svg>
        Enviar reserva
      </button>
    </div>

    <div class="success-msg" id="success-msg">
      <div class="check">🎉</div>
      <h3>¡Reserva recibida!</h3>
      <p>Te contactaremos en breve para confirmar tu mesa.</p>
      <button class="btn-secondary" onclick="resetForm()" style="margin-top:1.2rem">Nueva reserva</button>
    </div>
  </div>

  
  <div class="info-overlay" id="info-overlay">
    <div class="info-panel" role="dialog" aria-modal="true">
      <div class="info-panel__head">
        <h3>Información útil</h3>
        <button class="info-panel__close" onclick="closeInfo()" aria-label="Cerrar">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>

      <div class="info-row">
        <span class="info-ico">🕐</span>
        <div>
          <strong>Horario</strong>
          <span>Lunes a viernes: 08:00 – 17:00<br>Sábados: 07:00 – 16:00<br>Domingos: cerrado</span>
        </div>
      </div>
      <div class="info-row">
        <span class="info-ico">👥</span>
        <div>
          <strong>Grupos y celebraciones</strong>
          <span>Para grupos de más de 8 personas o eventos privados, contáctanos directamente.</span>
        </div>
      </div>
      <div class="info-row">
        <span class="info-ico">📞</span>
        <div>
          <strong>Teléfono directo</strong>
          <span>También puedes llamarnos al <a href="tel:+34959254960" style="color:var(--burdeos);font-weight:600">959 254 960</a></span>
        </div>
      </div>
      <div class="info-row">
        <span class="info-ico">⚠️</span>
        <div>
          <strong>Política de reservas</strong>
          <span>Mantenemos la mesa durante 15 minutos. Para cancelaciones avísanos con 2h de antelación.</span>
        </div>
      </div>
    </div>
  </div>
</main>

<div class="toast" id="toast"></div>

<?php $__env->startPush('scripts'); ?>
<script>
(function(){
  if(document.getElementById('r-fecha'))
    document.getElementById('r-fecha').min = new Date().toISOString().split('T')[0];

  let personas = 0;
  window.setPers = function(n, btn){
    personas = n;
    document.querySelectorAll('.pers-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
  };

  window.openInfo  = () => document.getElementById('info-overlay').classList.add('is-open');
  window.closeInfo = () => document.getElementById('info-overlay').classList.remove('is-open');
  document.getElementById('info-overlay').addEventListener('click', e => {
    if(e.target.id === 'info-overlay') closeInfo();
  });

  function toast(msg, type=''){
    const t = document.getElementById('toast');
    t.textContent = msg; t.className = 'toast show ' + type;
    setTimeout(() => t.className = 'toast', 4000);
  }

  window.submitReserva = async function(){
    const nombre   = document.getElementById('r-nombre').value.trim();
    const telefono = document.getElementById('r-tel').value.trim();
    const email    = document.getElementById('r-email').value.trim();
    const fecha    = document.getElementById('r-fecha').value;
    const hora     = document.getElementById('r-hora').value;
    const notas    = document.getElementById('r-notas').value.trim();

    if(!nombre)   { toast('Escribe tu nombre','error');    return; }
    if(!telefono) { toast('Escribe tu teléfono','error');  return; }
    if(!fecha)    { toast('Selecciona una fecha','error'); return; }
    if(!hora)     { toast('Selecciona la hora','error');   return; }
    if(!personas) { toast('Indica el número de personas','error'); return; }

    const btn = document.querySelector('[onclick="submitReserva()"]');
    btn.disabled = true;
    btn.innerHTML = '<span style="display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,.4);border-top-color:#fff;border-radius:50%;animation:rspin .7s linear infinite"></span> Enviando…';

    try {
      const csrf = document.querySelector('meta[name="csrf-token"]').content;
      const res = await fetch('<?php echo e(route("api.reserva")); ?>', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf },
        body: JSON.stringify({ nombre, telefono, email, fecha, hora, personas, notas })
      });
      const data = await res.json();
      if(data.ok){
        document.getElementById('form-area').style.display = 'none';
        document.getElementById('success-msg').style.display = 'block';
      } else {
        toast(data.mensaje || 'Error al enviar', 'error');
        btn.disabled = false; btn.innerHTML = '✈ Enviar reserva';
      }
    } catch(e){
      toast('Error de red. Inténtalo de nuevo.', 'error');
      btn.disabled = false; btn.innerHTML = '✈ Enviar reserva';
    }
  };

  window.resetForm = function(){
    ['r-nombre','r-tel','r-email','r-fecha','r-notas'].forEach(id => {
      const el = document.getElementById(id); if(el) el.value = '';
    });
    document.getElementById('r-hora').selectedIndex = 0;
    document.querySelectorAll('.pers-btn').forEach(b => b.classList.remove('selected'));
    personas = 0;
    document.getElementById('form-area').style.display = 'block';
    document.getElementById('success-msg').style.display = 'none';
  };
})();
</script>
<style>@keyframes rspin{to{transform:rotate(360deg)}}</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/vhosts/ieslamarisma.net/httpdocs/proyectos/2026/darioalfaro/laravel/mw_laravelWeb/resources/views/cliente/reservar.blade.php ENDPATH**/ ?>